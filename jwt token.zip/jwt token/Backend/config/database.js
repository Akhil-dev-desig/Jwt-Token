// configuring database connection
module.exports = {
    database: "mongodb://localhost:27017/usersdb",
    secret: "My Secret Key"
}
